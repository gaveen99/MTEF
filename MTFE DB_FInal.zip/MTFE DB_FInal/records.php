<!-- <form action="upload.php" method="post" enctype="multipart/form-data">
  <label for="csv_file">Upload CSV File:</label>
  <input type="file" name="csv_file" id="csv_file" />
  <br /> -->





















<?php

error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);
// Establish a connection to the MySQL database
$servername = "localhost:3306";
$dbusername = "naletans_MTFE__DB__1531";
$dbpassword = "Mtfe__1515";
$dbname = "naletans_MTFE";

$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form was submitted
if (isset($_POST['submit'])) {
    // Retrieve data submitted from the HTML form
    $id = $_POST['id'];
    $name = $_POST['name'];
    $p_number = $_POST['phone_number'];
    $email = $_POST['email'];
    $city = $_POST['city'];
    $whatsapp = $_POST['whatsapp_number'];
    $telegram = $_POST['telegram_number'];
    $leader = $_POST['leader_name'];
    $trader_stat = $_POST['trader_status'];
    $num_mem = $_POST['num_of_members'];

    // Sanitize the data
    $id = filter_var($id, FILTER_SANITIZE_STRING);
    $name = filter_var($name, FILTER_SANITIZE_STRING);
    $p_number = filter_var($p_number, FILTER_SANITIZE_STRING);
    $email = filter_var($email, FILTER_SANITIZE_EMAIL);
    $city = filter_var($city, FILTER_SANITIZE_STRING);
    $whatsapp = filter_var($whatsapp, FILTER_SANITIZE_STRING);
    $telegram = filter_var($telegram, FILTER_SANITIZE_STRING);
    $leader = filter_var($leader, FILTER_SANITIZE_STRING);
    $trader_stat = filter_var($trader_stat, FILTER_SANITIZE_STRING);
    $num_mem = filter_var($num_mem, FILTER_SANITIZE_STRING);






    // Insert the data into the MySQL database
    $sql = "INSERT INTO `USERS`(`id`, `name`, `p_number`, `email`, `city`, `whatsapp`, `telegram`, `leader`, `trader_stat`, `num_mem`) VALUES ('$id','$name', '$p_number', '$email', '$city', '$whatsapp', '$telegram', '$leader', '$trader_stat', $num_mem)";

    if ($conn->query($sql) === TRUE) {
      echo "<p style='color: #00FF00';>Data entred Sucessfully.</p>";
    } else {
        // echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close the database connection
$conn->close();
?>









<?php

error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);
// Establish a connection to the MySQL database
$host = "localhost:8889";
$username = "root";
$password = "root";
$dbname = "MTFE";

$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form was submitted
if (isset($_POST['csv_submit'])) {
    // Check if a file was uploaded
    if (isset($_FILES['csv_file']) && $_FILES['csv_file']['error'] == 0) {
        $csv_file = $_FILES['csv_file']['tmp_name'];
        $handle = fopen($csv_file, "r");
        if ($handle !== false) {

            $headers = fgetcsv($handle, 1000, ",");
            // Loop through each line in the CSV file
            while (($row = fgetcsv($handle, 1000, ",")) !== false) {
                // Retrieve data from the CSV file
         
                $id = $row[1];
                $name = $row[2];
                $p_number = $row[3];
                // $email = $row[4];
                $city = strtoupper($row[4]);
                $whatsapp = $row[5];
                $telegram = $row[6];
                $leader = strtoupper($row[7]);
                $trader_stat1 = $row[8];
                $num_mem = $row[9];

//                 $string =   $trader_stat1 ;
// // remove all non-English characters and numbers
//                 $trader_stat_str_rip = preg_replace("/[^A-Za-z ]/", '', $string);
// // remove extra whitespaces
//                 $trader_stat_str_rip = trim(preg_replace('/\s+/', ' ', $trader_stat_str_rip));
// // add comma between words
//                 $trader_stat_str_rip = str_replace('o ,',",", $trader_stat_str_rip);
//                 $trader_stat_str_rip = str_replace('Active Account',"Active Account,", $trader_stat_str_rip);

//                 echo $trader_stat_str_rip;



               


             
    
                // Sanitize the data str
                // $timestamp = filter_var($timestamp, FILTER_SANITIZE_STRING);
                $id = filter_var($id, FILTER_SANITIZE_STRING);
                $name = filter_var($name, FILTER_SANITIZE_STRING);
                $p_number = filter_var($p_number, FILTER_SANITIZE_STRING);
                // $email = filter_var($email, FILTER_SANITIZE_EMAIL);
                $city = filter_var($city, FILTER_SANITIZE_STRING);
                $whatsapp = filter_var($whatsapp, FILTER_SANITIZE_STRING);
                $telegram = filter_var($telegram, FILTER_SANITIZE_STRING);
                $leader = filter_var($leader, FILTER_SANITIZE_STRING);
                $trader_stat1 = filter_var($trader_stat1, FILTER_SANITIZE_STRING);
                $num_mem = filter_var( $num_mem, FILTER_SANITIZE_NUMBER_INT);

                if($num_mem==null)
                {
                    $num_mem=0;
                }

                $num_mem1 = preg_replace('/\s*\(as at \d{2}\.\d{2}\.\d{4}\)/', '', $num_mem);
                $num_mem2= preg_replace('/[^a-zA-Z0-9\s]/', 0, $num_mem1);
                $telegram2=preg_replace('/[^a-zA-Z0-9\s]/', 'N/A', $telegram);
                
                
// //  /^[a-zA-Z0-9!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]*$/
// preg_match($pattern, $str)
                // if( preg_match("/#$%^&*()+=-[]';,./{}|:<>?~/",$telegram))
                // {
                //     $telegram="N/A";
                // }


                // $mystr = 'abc';
                // $findMe   = 'a';
                // $position = strpos($mystr, $findMe);

                

// $position = strpos($telegram, "/#$%^&*()+=-[]';,./{}|:<>?~/");
// echo $position ;

    
                // Insert the data into the MySQL database
                // $sql = "INSERT INTO `USERS_TEST`(`id`, `name`, `p_number`, `city`, `whatsapp`, `telegram`, `leader`, `trader_stat`, `num_mem`) VALUES ('$id','$name', '$p_number', '$city', '$whatsapp', '$telegram', '$leader', '$trader_stat1', $num_mem)";
                $sql = "INSERT INTO `USERS_TEST`(`id`, `name`, `p_number`, `city`, `whatsapp`, `telegram`, `leader`, `trader_stat`, `num_mem`) VALUES ('$id','$name', '$p_number', '$city', '$whatsapp', '$telegram2', '$leader', '$trader_stat1', $num_mem2)";
                
                if ($conn->query($sql) === false) {
                    // echo "Error: " . $sql . "<br>" . $conn->error;
                }
            }
            fclose($handle);
            echo "<p style='color: #00FF00';>Data entred Sucessfully.</p>";
        } else {
            echo "Error: Unable to open file.";
        }
    } else {
        // echo "Error: No file uploaded.";
        echo "<p style='color:#FF0000';>Error: No file uploaded.</p>";

       
    }
}

// Close the database connection
$conn->close();
?>




<!-- ---------------------------------------------------------------------------------------------------- -->




<!DOCTYPE html>
<html lang="en">
   <head>
     <style>

      .form
      {
         align-items:800px;
      }

   .container_csv{

         margin-left: 8000px;
  
   }

   .vl {
         border-left: 2px solid rgba(53, 53, 53, 0.745);
         height: 960px;
         position: absolute;
         left: 50%;
         margin-left: -3px;
         top: 400;
         opacity: 0.5;
         padding: auto;
}


.hide{
   display: inline-block;
    padding: 12px 30px;
    cursor: pointer;
    background-image: linear-gradient(135deg, #546FE7 0%, #546FE7 100%);
    border-radius: 50px;
    color: #FFF;
    font-size: 1.1em;
    box-shadow: 0 3px 6px rgba(0, 0, 0, 0.2);
    position: relative;
    overflow: hidden;
    transition: background-color 0.3s, box-shadow 0.3s;
}



.hide::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    height: 100%;
    width: 0;
    background-color: rgba(255, 255, 255, 0.2);
    transition: width 0.5s;
}

.hide:hover {
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
}

.hide:hover::before {
    width: 100%;
}


 
     </style>
      <!-- basic -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title>Add User</title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- bootstrap css -->
      <link rel="stylesheet" href="css/bootstrap.min.css">
      <!-- style css -->
      <link rel="stylesheet" href="css/style.css">
      <!-- Responsive-->
      <link rel="stylesheet" href="css/responsive.css">
      <!-- fevicon -->
      <link rel="icon" href="images/fevicon.png" type="image/gif" />
      <!-- Tweaks for older IEs-->
      <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->

    
   </head>
   <!-- body -->
   <body class="main-layout inner_page">
      <!-- loader  -->
      <div class="loader_bg">
         <div class="loader"><img src="images/loading.gif" alt="#"/></div>
      </div>
      <!-- end loader -->
      <!-- header -->
      <div class="header">
         <div class="container">
            <div class="row d_flex">
               <div class=" col-md-2 col-sm-3 col logo_section">
                  <div class="full">
                     <div class="center-desk">
                        <div class="logo">
                           <a href="index.html"><img src="images/mtfelogo.png" alt="#" /></a>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-md-8 col-sm-12">
                  <nav class="navigation navbar navbar-expand-md navbar-dark ">
                     <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample04" aria-controls="navbarsExample04" aria-expanded="false" aria-label="Toggle navigation">
                     <span class="navbar-toggler-icon"></span>
                     </button>

                     <div class="collapse navbar-collapse" id="navbarsExample04">
                        <ul class="navbar-nav mr-auto">
                           <li class="nav-item active">
                              <a class="nav-link" href="citytest.php">SEARCH BY CITY</a>
                           </li>
                           <li class="nav-item">
                              <a class="nav-link" href="leader_list.html">LEADER LIST</a>
                           </li>
                           <li class="nav-item">
                              <!-- <button id="aj_btn", class="aj_btn">
                                 <img src="images/lock_27px.png" alt="" class="lock">
                                 <span>LOGOUT</span>
                                 <a class="nav-link" href="delete.php"></a>
                               </button> -->

                               <li class="nav-item">
                              <a class="nav-link" href="logout.php">Log Out</a>
                           </li>

                               <li class="nav-item">
                              <a class="nav-link" href="leader_list.html"> <?php
    // session_start();
    if(isset($_SESSION['username'])) {
      $email = $_SESSION['username'];
      // $roles = $_SESSION['role'];

      // $sql2 = "SELECT 'role' FROM accounts WHERE id = '$email'";
      // $result2 = mysqli_query($conn, $sql2);

      
      $textBeforeAt = strstr($email, '@', true);




      if(str_contains($email, '@')==1)
      {
          echo "Hi, " . $textBeforeAt;
         // echo "Hi, " . $mysqli_fetch_assoc($result2);
      }
      else
      { echo "Hi, " . $email;
      }

     
    }
   




?></a>
                           </li>
                              
                        </li>
                           <!-- <li class="nav-item">
                              <a class="nav-link" href="domain.html">Domain</a>
                           </li>
                          
                           <li class="nav-item">
                              <a class="nav-link" href="contact.html">Contact Us</a>
                           </li> -->
                        </ul>
                     </div>
                  </nav>
               </div>
               <div class="col-md-2  d_none">
                  <ul class="email text_align_right">
                     <!-- <li><a href="Javascript:void(0)"> <i class="fa fa-shopping-bag" aria-hidden="true"> <span>0</span></i>
                        </a>
                     </li>
                     <li><a href="Javascript:void(0)">Sign In
                        </a>
                     </li> -->
                  </ul>
               </div>
            </div>
         </div>
      </div>
      <!-- end header inner -->
      <!-- contact -->
      <div class="contact">
         <div class="container">
            <div class="row ">
               <div class="col-md-12">
                  <div class="titlepage text_align_center">
                     <h2>ADD <span class="blue_light">USER</span></h2>
                     
                     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                     <div class="vl"></div>
                     <h2 class="add">UPLOAD <span class="blue_light">USERS</span></h2>
<br><br>
<div id="drop_zone" class="drop_zone" align="right">
          
                            
 <form method="post" enctype="multipart/form-data">   
   <input type="file" class="hide" name="csv_file" id="csv_file" accept=".csv">
   <input type="submit" class="hide" name="csv_submit" value="Upload">
 </form>
	
	</div>
                    
                  </div>
                  <!-- create a page using php for registration on the following fields: username,role,password,confirm password and send it to sql server and encrypt the password -->
             

              

               
                   <!-- <div id="drop_zone" class="drop_zone" onclick="dropzoneClick()" accept=".csv" class="well"><h1><i class="fa fa-cloud-upload" style="font-size:36px"></i> Drag Files to Upload or Browse Files</h1></div>
                   <input type="file" name="file" id="file" class="hide"/>
                  </div>
               </div> -->


<!-- csv file space -->



            
               <div class="col-md-10 offset-md-1">
                   <form id="request" class="main_form" form method="post" enctype="multipart/form-data">
                     <div class="row">
                        <div class="col-md-12 ">
                        <input class="contactus" type="text" name="id" id="id" placeholder="MTFE ID"/>
                        </div>
                        <div class="col-md-12">
                           <input class="contactus" placeholder="Name" type="type" name="name" id="name">                          
                        </div>
                        <div class="col-md-12">
                           <input class="contactus" placeholder="Contact Number" type="tel" name="phone_number" id="phone_number" >                          
                        </div>
                        <div class="col-md-12">
                           <input class="contactus" placeholder="Email Address" type="email" name="email" id='email'>                          
                        </div>
                        <div class="col-md-12">
                           <input class="contactus" placeholder="City" type="type" name="city" id="city">                          
                        </div>
                        <div class="col-md-12">
                           <input class="contactus" placeholder="WhatsApp Number" type="tel" name="whatsapp_number" id="whatsapp_number">                          
                        </div>
                        <div class="col-md-12">
                           <input class="contactus" placeholder="Telegram Number" type="tel" name="telegram_number" id="telegram_number">                          
                        </div>
                        <div class="col-md-12">
                        <input class="contactus" type="text" name="leader_name" placeholder="leader Name" id="leader_name" />                       
                        </div>

                        <div class="col-md-12">
                     
                        

                        <label for="trader_status">Trader Status:</label>
                        <select class="contactus" name="trader_status" id="trader_status">
                       <option value="Active">Active</option>
                        <option value="Inactive">Inactive</option>
                        </select>
                        <br />

                         </div>
                        <div class="col-md-12">
                           <input class="contactus" placeholder="Number of Members" type="number" name="num_of_members" id="num_of_members">                          
                        </div>
                       
                        <!-- <div class="col-md-12">
                           <textarea class="textarea" placeholder="Message" type="type" Message="Name"></textarea>
                        </div> -->
                        <div class="col-md-12">
                        

                           <input class="send_btn"  class="contactus" type="submit" name="submit" value="ADD USER" /> 
                        </div>
                     </div>
                  </form>
               </div>
               </div>
            
               
            <!-- <div class="csv">
               <form class="box" method="post" action="" enctype="multipart/form-data">
                  <div class="box__input">
                    <input class="box__file" type="file" name="files[]" id="file" data-multiple-caption="{count} files selected" multiple />
                    <label for="file"><strong>Choose a file</strong><span class="box__dragndrop"> or drag it here</span>.</label>
                    <button class="box__button" type="submit">Upload</button>
                  </div>
                  <div class="box__uploading">Uploading…</div>
                  <div class="box__success">Done!</div>
                  <div class="box__error">Error! <span></span>.</div>
                </form>

         
            </div> -->
         </div>
      </div>

      
      <!-- contact -->
      <!--  footer -->
      <footer>
         <div class="footer">
            <div class="container">
               <div class="row">
                  <div class="col-lg-3 col-md-6 col-sm-6">
                     <div class="infoma text_align_left">
                        <!-- <h3>Choose.</h3>
                        <ul class="commodo">
                           <li>Commodo</li>
                           <li>consequat. Duis a</li>
                           <li>ute irure dolor</li>
                           <li>in reprehenderit </li>
                           <li>in voluptate </li>
                        </ul> -->
                     </div>
                  </div>
                  <div class="col-lg-4 col-md-6 col-sm-6">
                     <div class="infoma">
                        <!-- <h3>Get Support.</h3> -->
                        <ul class="conta">
                           <li><i class="fa fa-map-marker" aria-hidden="true"></i>Address : No.44, Pagoda Road, Nugegoda
                           </li>
                           <li><i class="fa fa-phone" aria-hidden="true"></i>Call : +94 70 100 1315</li>
                           <li> <i class="fa fa-envelope" aria-hidden="true"></i><a href="Javascript:void(0)"> Email : mtfesrilanka@gmail.com</a></li>
                        </ul>
                     </div>
                  </div>
                  <div class="col-lg-3 col-md-6 col-sm-6">
                     <div class="infoma">
                        <h3>MTFE</h3>
                        <ul class="menu_footer">
                           <li><a href="index.html">Dashboard</a></li>
                           <li><a href="search_by_city.html">Search by City </a></li>
                           <li><a href="leader_list.html">Leader List</a></li>
                           <li><a href="add_users.html">Add User</a></li>
                           <li><a href="update_delete.html">Update/Delete</a></li>
                        </ul>
                     </div>
                  </div>
                  <div class="col-lg-2 col-md-6 col-sm-6">
                     <div class="infoma text_align_left">
                        <!-- <h3>Services.</h3>
                        <ul class="commodo">
                           <li>Commodo</li>
                           <li>consequat. Duis a</li>
                           <li>ute irure dolor</li>
                           <li>in reprehenderit </li>
                           <li>in voluptate </li>
                        </ul> -->
                     </div>
                  </div>
               </div>
            </div>
            <div class="copyright">
               <div class="container">
                  <div class="row">
                     <div class="col-md-12">
                        <p>© <script>document.write(/\d{4}/.exec(Date())[0])</script> All Rights Reserved. <a href="https://html.design/"> MTFEUSERDATABASE</a></p>
                  </div>
               </div>
            </div>
         </div>
      </footer>
      <!-- end footer -->
      <!-- Javascript files-->

      <script src="js/jquery.min.js"></script>
      <script src="js/bootstrap.bundle.min.js"></script>
      <!-- sidebar -->
      <script src="js/custom.js"></script>
      
      
      <script>
         $.PAYLOAD = new Object();

            $(document).ready(function(){
               $("#file").change(handleFileSelect);
            });

            function handleFileDrop(evt) {
            evt.stopPropagation();
            evt.preventDefault();

            var files = evt.dataTransfer.files; 
            console.log('Caught a File!');
            doUpload(files[0]);
            console.log($.PAYLOAD);
            }

            function handleDragOver(evt) {
            evt.stopPropagation();
            evt.preventDefault();
            evt.dataTransfer.dropEffect = 'copy'; // Explicitly show this is a copy.
            // loading data
            // change color etc
            }

            var dropzone = $('#dropzone');
            dropzone.addEventListener('dragover', handleDragOver, false);
            dropzone.addEventListener('drop', handleFileDrop, false);

            function doUpload(e) { 
            console.log('attempt');
            Papa.parse(e, {
               header:true,
               before: function(file, inputElem){ console.log('Attempting to Parse...')},
               error: function(err, file, inputElem, reason){ console.log(err); },
               complete: function(results, file){ $.PAYLOAD = results; }
            });
            }

            function dropzoneClick(evt){
            $('#file').click();
            }

            
            
            function handleFileSelect(evt) {
            var file = evt.target.files[0];

            Papa.parse(file, {
               header: true,
               dynamicTyping: true,
               complete: function(results) {
                  console.log(results);
               }
            });
            }
            
  

      </script>

      <!-- <script>

               if (isAdvancedUpload) {

               var droppedFiles = false;

               $form.on('drag dragstart dragend dragover dragenter dragleave drop', function(e) {
               e.preventDefault();
               e.stopPropagation();
               })
               .on('dragover dragenter', function() {
               $form.addClass('is-dragover');
               })
               .on('dragleave dragend drop', function() {
               $form.removeClass('is-dragover');
               })
               .on('drop', function(e) {
               droppedFiles = e.originalEvent.dataTransfer.files;
               });

               }
      </script> -->

      <!-- <script>

            if (isAdvancedUpload) {

            var droppedFiles = false;

            $form.on('drag dragstart dragend dragover dragenter dragleave drop', function(e) {
            e.preventDefault();
            e.stopPropagation();
            })
            .on('dragover dragenter', function() {
            $form.addClass('is-dragover');
            })
            .on('dragleave dragend drop', function() {
            $form.removeClass('is-dragover');
            })
            .on('drop', function(e) {
            droppedFiles = e.originalEvent.dataTransfer.files;
            });

            }
      </script> -->
   </body>
</html>