


<?php

$servername = "localhost:3306";
$dbusername = "naletans_MTFE__DB__1531";
$dbpassword = "Mtfe__1515";
$dbname = "naletans_MTFE";
$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);


if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if the form has been submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Escape user inputs to prevent SQL injection attacks
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    $hashed_password = hash('sha256', $password);

    // SQL query to retrieve user information
    $sql = "SELECT * FROM accounts WHERE username='$username' and password='$hashed_password'";
    $result = mysqli_query($conn, $sql);

    // Check if the query returned any results
    $count = mysqli_num_rows($result);

    // If the user is found, set the session variables and redirect to the dashboard
    if ($count == 1) {
        session_start();
        $_SESSION['username'] = $username;
        header("location: front.php");
    } else {
        $error = "Your Login Name or Password is invalid";
    }
}

// Check if the user is already logged in
session_start();
if (isset($_SESSION['username'])) {
    header("location: front.php");
}


?>


<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Login Page in HTML with CSS Code Example</title>
  <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">


<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous"><link rel="stylesheet" href="./login_style.css">

</head>
<body>

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<!-- partial:index.partial.html -->
<div class="box-form">
	<div class="left">
		<div class="overlay">
		<h1> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</h1>
		<!-- <p>MTFESL GROUP</p> -->
		<!-- <span>
			<p>login with social media</p>
			<a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
			<a href="#"><i class="fa fa-twitter" aria-hidden="true"></i> Login with Twitter</a>
		</span> -->
		</div>
	</div>
	
	
		<div class="right">
		<h5>Login</h5>
		<p>Don't have an account? <a href="#">Creat Your Account</a> it takes less than a minute</p>
		<div class="inputs">
		<form method="post" onsubmit="return validateForm()">
	
		<input type="text" name="username" required placeholder="USERNAME"><br><br>
	
		<input type="password" name="password"required placeholder="PASSWORD"><br><br>
		<input type="submit" value="Login" class="btl">
	</form>
    <?php if (isset($error)) {
        echo "<p style='color:#FF0000';>$error</p>";
    } ?>
		</div>
			
			<br><br>
			
		<div class="remember-me--forget-password">
				<!-- Angular -->
 
			<!-- <p>forget password?</p> -->
		</div>
			
			
			<!-- <button>Login</button> -->
	</div>
	
</div>
<!-- partial -->
  
</body>
</html>


