<!DOCTYPE html>
<html>
<head>
	<title>Login Page</title>
</head>
<body>

	<h1>Login Page</h1>

	<?php
		// Check if the form has been submitted
		if ($_SERVER["REQUEST_METHOD"] == "POST") {
			
			// Collect form data
			$username = $_POST['username'];
			$password = $_POST['password'];

			// Connect to the SQL server
			// $servername = "localhost";
			// $username_db = "your_username";
			// $password_db = "your_password";
			// $dbname = "your_database_name";


            $servername = "localhost:8889";
            $username_db = "root";
            $password_db = "root";
            $dbname = "MTFE";

			$conn = mysqli_connect($servername, $username_db, $password_db, $dbname);

			// Check connection
			if (!$conn) {
			  die("Connection failed: " . mysqli_connect_error());
			}

			// Query the database for the user's information
			$sql = "SELECT * FROM accounts WHERE username='$username'";

			$result = mysqli_query($conn, $sql);

			// Check if the user exists and if the password is correct
			if (mysqli_num_rows($result) == 1) {
				$row = mysqli_fetch_assoc($result);
				if (password_hash($password, PASSWORD_BCRYPT) === $row['password']) { 
					echo "<p>Login successful!</p>";
				} else {
					echo "<p>Incorrect password. Please try again.</p>";
				}
			} else {
				echo "<p>User not found. Please try again.</p>";
			}

			mysqli_close($conn);

		}
	?>

	<form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
		<label for="username">Username:</label>
		<input type="text" id="username" name="username"><br><br>
		<label for="password">Password:</label>
		<input type="password" id="password" name="password"><br><br>
		<input type="submit" value="Login">
	</form>

</body>
</html>
