
<?php
// Replace with your own SQL Server credentials
// $servername = "localhost";
// $username = "username";
// $password = "password";
// $dbname = "your_database";

$servername = "localhost:3306";
$dbusername = "naletans_MTFE__DB__1531";
$dbpassword = "Mtfe__1515";
$dbname = "naletans_MTFE";

// Create a new connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get form data
$user = $_POST["username"];
$role = $_POST["role"];
$pass = $_POST["password"];
$confirm_pass = $_POST["confirm_password"];

// Check if passwords match
if ($pass !== $confirm_pass) {
    echo "Passwords do not match!";
    exit();
}

// Encrypt the password
$encrypted_pass = hash("sha256", $pass);

// Insert the user data into the SQL Server
$sql = "INSERT INTO users_new ('username', 'role', 'password') VALUES (?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sss", $user, $role, $encrypted_pass);

if ($stmt->execute()) {
    echo "Registration successful!";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$stmt->close();
$conn->close();
?>




<!-- register.html -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form</title>
</head>
<body>
    <h1>Registration Form</h1>
    <form method="post">
        <label for="username">Username:</label>
        <input type="text" name="username" id="username" required><br>
        <!-- <label for="role">Role:</label>
        <input type="text" name="role" id="role" required><br> -->


        <label for="trader_status">Role:</label>
                        <select class="contactus" name="role" id="role">
                       <option value="CEO">CEO</option>
                        <option value="ADMIN">ADMIN</option>
                        </select>




        <label for="password">Password:</label>
        <input type="password" name="password" id="password" required><br>
        <label for="confirm_password">Confirm Password:</label>
        <input type="password" name="confirm_password" id="confirm_password" required><br>
        <input type="submit" name="submit" value="Register">
    </form>
</body>
</html>
