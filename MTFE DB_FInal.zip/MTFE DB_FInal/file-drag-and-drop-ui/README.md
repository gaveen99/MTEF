# File Drag and Drop UI

A Pen created on CodePen.io. Original URL: [https://codepen.io/gaveen-madhawa/pen/jOeNNBE](https://codepen.io/gaveen-madhawa/pen/jOeNNBE).

A custom Drag-n-Drop File Input built using HTML-CSS-JS