<!DOCTYPE html>
<html>
<head>

<meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title>Dashboard</title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- bootstrap css -->
      <link rel="stylesheet" href="css/bootstrap.min.css">
      <!-- style css -->
      <link rel="stylesheet" href="css/style.css">
      <!-- Responsive-->
      <link rel="stylesheet" href="css/responsive.css">
      <!-- fevicon -->
      <link rel="icon" href="images/fevicon.png" type="image/gif" />
      <!-- Tweaks for older IEs-->
      <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">

  <title>Search By City</title>
  <style>
    .side-panel {
      position: fixed;
      top: 0;
      left: 0;
      bottom: 0;
      width: 200px;
      background-color: #546FE7;
      color: #fff;
      padding: 20px;
    }

    .side-panel ul {
      list-style: none;
      padding: 30px;
      margin: 0;
    }

    .side-panel li {
      margin-bottom: 10px;
    }

    .side-panel button {
      border-radius: 25%;
      box-shadow:0.25rem 0.25rem 0.5rem rgba(0, 0, 0, 0.25);
      background-color: #fff;
      color: rgb(0, 0, 0);
      padding: 12px 24px;
      font-size: 16px;
      cursor: pointer;
      width: 100%;
      border: none;
    }

    .side-panel button:hover {
      background-color: #e7e7e7;
    }

    h1 {
      margin-top: 0;
      font-size: 24px;
    }

    .data-table-container {
      /* position: sticky;
   
  
  top: 20px;
  left: 220px;  */
  position: fixed;
  top: 20px;
  left: 20%;

     
  
    }

    table {
      width: 70%;
      border-collapse: collapse;

    
      
    }
    th, td {
      border: 1px solid #dddddd;
      padding: 8px;
      text-align: left;
    }
    th {
      background-color: #dddddd;
    }
    
  </style>
</head>

<body>
<br>
<div class="header" >
         <div class="container" >
            <div class="row d_flex">
               <div class=" col-md-2 col-sm-3 col logo_section">
                  <div class="full" style=" top: 20px; left: 60%;">
                     <div class="center-desk">
                        <div class="logo">
                           
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-md-8 col-sm-12">
                  <nav class="navigation navbar navbar-expand-md navbar-dark ">
                     <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample04" aria-controls="navbarsExample04" aria-expanded="false" aria-label="Toggle navigation">
                     <span class="navbar-toggler-icon"></span>
                     </button>

                     <div class="collapse navbar-collapse" id="navbarsExample04">
                        <ul class="navbar-nav mr-auto">
                           <li class="nav-item active">
                              <a class="nav-link" href="citytest.php">SEARCH BY CITY</a>
                           </li>
                           <li class="nav-item">
                              <a class="nav-link" href="leader_list.html">LEADER LIST</a>
                           </li>
                           <li class="nav-item">
                              <!-- <button id="aj_btn", class="aj_btn">
                                 <img src="images/lock_27px.png" alt="" class="lock">
                                 <span>LOGOUT</span>
                                 <a class="nav-link" href="delete.php"></a>
                               </button> -->

                               <li class="nav-item">
                              <a class="nav-link" href="logout.php">Log Out</a>
                           </li>


                           <li class="nav-item">
                              <a class="nav-link" href="front.php">HOME</a>
                           </li>
                               
                           
                              
                              <?php
    // session_start();
    if(isset($_SESSION['username'])) {
      $email = $_SESSION['username'];
      // $roles = $_SESSION['role'];

      // $sql2 = "SELECT 'role' FROM accounts WHERE id = '$email'";
      // $result2 = mysqli_query($conn, $sql2);

      
      $textBeforeAt = strstr($email, '@', true);




      if(str_contains($email, '@')==1)
      {
          echo "Hi, " . $textBeforeAt;
         // echo "Hi, " . $mysqli_fetch_assoc($result2);
      }
      else
      { echo "Hi, " . $email;
      }

     
    }
   




?></a>
                           </li>
                              
                        </li>
                           <!-- <li class="nav-item">
                              <a class="nav-link" href="domain.html">Domain</a>
                           </li>
                          
                           <li class="nav-item">
                              <a class="nav-link" href="contact.html">Contact Us</a>
                           </li> -->
                        </ul>
                     </div>
                  </nav>
               </div>
               <div class="col-md-2  d_none">
                  <ul class="email text_align_right">
                     <!-- <li><a href="Javascript:void(0)"> <i class="fa fa-shopping-bag" aria-hidden="true"> <span>0</span></i>
                        </a>
                     </li> -->
                     <!-- <li><a href="Javascript:void(0)">Sign In
                        </a>
                     </li> -->
                  </ul>
               </div>
            </div>
         </div>
      </div>
<br><br><br><br><br><br><br><br><br><br><br><br>
  <div class="side-panel">
    <h1>Search by Leader</h1>

<br><br>
    <?php
      // Connect to the SQL database
      // Connection variables
      $host = "localhost:8889";
      $user = "root";
      $password = "root";
      $database = "MTFE";
      // Connect to the database
      $conn = mysqli_connect($host, $user, $password, $database);
      // Retrieve the data from the database
      $result = mysqli_query($conn, "select DISTINCT leader from USERS ORDER BY leader ASC");
      // Loop through the results and create a button for each record
      while ($row = mysqli_fetch_assoc($result)) {
        $button_text = $row['leader'];
        echo "<button class='city-button'>$button_text</button>";
        
      }
    ?>
  </div>
  <div class="data-table-container">
  </div>
</body>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
  $(document).ready(function() {
    $(".city-button").click(function() {
      var city = $(this).text();
      $.ajax({
        type: "POST",
        url: "get_leader_data.php",
        data: { city: city },
        success: function(data) {
          $(".data-table").remove(); // Remove any previously added tables
          $(".data-table-container").append('<div class="data-table">' + data + '</div>');
        }
      });
    });
  });
</script>


<br><br><br><br><br><br><br><br><br>
<footer>
         <div class="footer">
            <div class="container">
               <div class="row">
                  <div class="col-lg-3 col-md-6 col-sm-6">
                     <div class="infoma text_align_left">
                        <!-- <h3>Choose.</h3>
                        <ul class="commodo">
                           <li>Commodo</li>
                           <li>consequat. Duis a</li>
                           <li>ute irure dolor</li>
                           <li>in reprehenderit </li>
                           <li>in voluptate </li>
                        </ul> -->
                     </div>
                  </div>
                  <div class="col-lg-4 col-md-6 col-sm-6">
                     <div class="infoma">
                        <!-- <h3>Get Support.</h3> -->
                        <ul class="conta">
                           <li><i class="fa fa-map-marker" aria-hidden="true"></i>Address : No.44, Pagoda Road, Nugegoda
                           </li>
                           <li><i class="fa fa-phone" aria-hidden="true"></i>Call : +94 70 100 1315</li>
                           <li> <i class="fa fa-envelope" aria-hidden="true"></i><a href="Javascript:void(0)"> Email : mtfesrilanka@gmail.com</a></li>
                        </ul>
                     </div>
                  </div>
                  <div class="col-lg-3 col-md-6 col-sm-6">
                     <div class="infoma">
                        <h3>MTFE</h3>
                        <ul class="menu_footer">
                           <li><a href="front.pdf">Dashboard</a></li>
                           <li><a href="citytest2.php">Search by City </a></li>
                           <li><a href="leadertest2.php">Leader List</a></li>
                           <li><a href="records.php">Add User</a></li>
                           <li><a href="update.php">Update/Delete</a></li>

                        </ul>
                     </div>
                  </div>
                  <div class="col-lg-2 col-md-6 col-sm-6">
                     <div class="infoma text_align_left">
                        <!-- <h3>Services.</h3>
                        <ul class="commodo">
                           <li>Commodo</li>
                           <li>consequat. Duis a</li>
                           <li>ute irure dolor</li>
                           <li>in reprehenderit </li>
                           <li>in voluptate </li>
                        </ul> -->
                     </div>
                  </div>
               </div>
            </div>
            <div class="copyright">
               <div class="container">
                  <div class="row">
                     <div class="col-md-12">
                        <p>© <script>document.write(/\d{4}/.exec(Date())[0])</script> All Rights Reserved. <a href="https://html.design/"> MTFEUSERDATABASE</a></p>
                        <!-- <script>document.write(/\d{4}/.exec(Date())[0])</script> -->
                         
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </footer>

</html>
