

<!-- ddddddddd -->


<?php

session_start();
// Check if user is not logged in
if (!isset($_SESSION['username'])) {
  // Redirect to login page
  header('Location: login.php');
  exit();
}




  // Connection variables
  $servername = "localhost:3306";
  $dbusername = "naletans_MTFE__DB__1531";
  $dbpassword = "Mtfe__1515";
  $dbname = "naletans_MTFE";
  
  // Connect to the database
  $conn = mysqli_connect($host, $user, $password, $database);
  
  // Check connection
  if (!$conn) {
    die("Connection failed: ");
  }


  $host = "localhost:8889";
$user = "root";
$password = "root";
$database = "MTFE";

// Connect to the database
$conn = mysqli_connect($host, $user, $password, $database);

// Check connection
if (!$conn) {
  die("Connection failed: ");
}
  


?>



<!DOCTYPE html>
<html lang="en">
   <head>
      <style>


               .contact_tab{

               text-align: center;
               width: 100%;
                border-collapse: collapse; 
               margin-bottom: 20px;
               }
                  th, td {
                  border: 1px solid #dddddd;
                  padding: 20px;
                  width:40px;
               
                  
                  }
                  th {
                     border: 0px;
                     
                     /* background-color: #141b43; */
                     text-align: center;
                     color: #fff;
                     background-image: linear-gradient(to right, #141b43 0%, #141b43 100%);
                  
                  }


                  .send_btn{

                     border-radius: 0.45em;
                     padding: 40px;
                     box-shadow: 0 9px #999;
                     padding: 0.5em 2.0em;
                     width: fit-content;
                     font-weight: bold;
                     border: none;
                     align-self: center;
                     /* background-color: #13172d; */
                     color: #fff;
                     background-image: linear-gradient(to right, #141b43 0%, #141b43 100%);
                     /* background-image: linear-gradient(to right, #fbc2eb 0%, #a6c1ee 51%, #fbc2eb 100%); */
                     

                  }
      </style>
      
      <!-- basic -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title>Update_Delete</title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- bootstrap css -->
      <link rel="stylesheet" href="css/bootstrap.min.css">
      <!-- style css -->
      <link rel="stylesheet" href="css/style.css">
      <!-- Responsive-->
      <link rel="stylesheet" href="css/responsive.css">
      <!-- fevicon -->
      <link rel="icon" href="images/fevicon.png" type="image/gif" />
      <!-- Tweaks for older IEs-->
      <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
   </head>
   <!-- body -->
   <body class="main-layout inner_page">
      <!-- loader  -->
      <div class="loader_bg">
         <div class="loader"><img src="images/loading.gif" alt="#"/></div>
      </div>
      <!-- end loader -->
      <!-- header -->
      <div class="header">
         <div class="container">
            <div class="row d_flex">
               <div class=" col-md-2 col-sm-3 col logo_section">
                  <div class="full">
                     <div class="center-desk">
                        <div class="logo">
                           <a href="index.html"><img src="images/mtfelogo.png" alt="#" /></a>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-md-8 col-sm-12">
                  <nav class="navigation navbar navbar-expand-md navbar-dark ">
                     <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample04" aria-controls="navbarsExample04" aria-expanded="false" aria-label="Toggle navigation">
                     <span class="navbar-toggler-icon"></span>
                     </button>
                     <div class="collapse navbar-collapse" id="navbarsExample04">
                        <ul class="navbar-nav mr-auto">
                           <li class="nav-item active">
                              <a class="nav-link" href="search_by_city.html">SEARCH BY CITY</a>
                           </li>
                           <li class="nav-item">
                              <a class="nav-link" href="leader_list.html">LEADER LIST</a>
                           </li>
                           <li class="nav-item">
                              <button id="aj_btn", class="aj_btn">
                                 <img src="images/lock_27px.png" alt="" class="lock">
                                 <span>LOGOUT</span>

                                 <li class="nav-item">
                              <a class="nav-link" href="leader_list.html"> <?php
    // session_start();
    if(isset($_SESSION['username'])) {
      echo "Hi, " . $_SESSION['username'];
    }
   




?></a>
                               </button>

                        </li>
                           <!-- <li class="nav-item">
                              <a class="nav-link" href="hosting.html">Hosting</a>
                           </li>
                           <li class="nav-item">
                              <a class="nav-link" href="domain.html">Domain</a>
                           </li>
                           <li class="nav-item active">
                              <a class="nav-link" href="contact.html">Contact Us</a> -->
                         
                        </ul>
                     </div>
                  </nav>
               </div>
               <div class="col-md-2  d_none">
                  <ul class="email text_align_right">
                     <!-- <li><a href="Javascript:void(0)"> <i class="fa fa-shopping-bag" aria-hidden="true"> <span>0</span></i>
                        </a>
                     </li> -->
                     <!-- <li><a href="Javascript:void(0)">Sign In
                        </a>
                     </li> -->
                  </ul>
               </div>
            </div>
         </div>
      </div>
      <!-- end header inner -->
      <!-- contact -->
      <div class="contact">
         <div class="container">
            <div class="row ">
               <div class="col-md-12">
                  <div class="titlepage text_align_center">
                     <h2>ED<span class="blue_light">IT</span></h2>
                  </div>
               </div>
               <div class="col-md-10 offset-md-1">
                  <!-- <form id="request" class="main_form">
                     <div class="row">
                        <div class="col-md-12 ">
                           <input class="contactus" placeholder="Name" type="type" name=" Name"> 
                        </div>
                        <div class="col-md-12">
                           <input class="contactus" placeholder="Phone number" type="type" name="Phone Number">                          
                        </div>
                        <div class="col-md-12">
                           <input class="contactus" placeholder="Your Email" type="type" name="Email">                          
                        </div>
                        <div class="col-md-12">
                           <textarea class="textarea" placeholder="Message" type="type" Message="Name"></textarea>
                        </div>
                        <div class="col-md-12">
                           <button class="send_btn">Submit Now</button>
                        </div>
                     </div>
                  </form> -->



                  <div class="contact_tab" >
   <table>
               <?php


if (isset($_POST['searchButton']) && !empty($_POST['searchTerm'])) {
    $searchTerm = $_POST['searchTerm'];
  
    // Query the database with the search term
    $sql = "SELECT  `id`, `name`, `p_number`, `email`, `city`, `whatsapp`, `telegram`, `leader`, `trader_stat`, `num_mem` FROM  `USERS` WHERE `name` LIKE '%$searchTerm%' OR `city` LIKE '%$searchTerm%'OR `id` LIKE '%$searchTerm%'OR `email` LIKE '%$searchTerm%'OR `whatsapp` LIKE '%$searchTerm%'OR `telegram` LIKE '%$searchTerm%'OR `p_number` LIKE '%$searchTerm%'";
    $result = mysqli_query($conn, $sql);
  } else {
    // Query the database for all users
    $sql = "SELECT * FROM `USERS` ORDER BY LPAD(lower(id), 0,0) asc;";
    $result = mysqli_query($conn, $sql);
  }
               // Check if the query returned any results
if (mysqli_num_rows($result) > 0) {
    // Start creating the HTML table

  
    echo "<thead>";
    echo "<tr>";
    echo "<th>ID</th>";
    echo "<th>Name</th>";
    echo "<th>Phone Number</th>";
    echo "<th>Email</th>";
    echo "<th>City</th>";
    echo "<th>Whatsapp Number</th>";
    echo "<th>Telegram Number</th>";
    echo "<th>Leader Name</th>";
    echo "<th>Trader Status</th>";
    echo "<th>Number of Members</th>";
    echo "</tr>";
    echo "</thead>";
    echo "<tbody>";
}
  
  while ($row = mysqli_fetch_assoc($result)) {
      echo "<tr>";
      echo "<form method='POST' action='manage_record.php'>";
      echo "<input type='hidden' name='id' value='" . $row["id"] . "'>";
      echo "<td>" . $row["id"] . "</td>";
      echo "<td><input type='text' name='name' value='" . $row["name"] . "'></td>";
      echo "<td><input type='text' name='p_number' value='" . $row["p_number"] . "'></td>";
      echo "<td><input type='text' name='email' value='" . $row["email"] . "'></td>";
      echo "<td><input type='text' name='city' value='" . $row["city"] . "'></td>";
      echo "<td><input type='text' name='whatsapp' value='" . $row["whatsapp"] . "'></td>";
      echo "<td><input type='text' name='telegram' value='" . $row["telegram"] . "'></td>";
      echo "<td><input type='text' name='leader' value='" . $row["leader"] . "'></td>";
      echo "<td><input type='text' name='trader_stat' value='" . $row["trader_stat"] . "'></td>";
      echo "<td><input type='text' name='num_mem' value='" . $row["num_mem"] . "'></td>";
      echo "<td><button type='submit' name='action' value='delete'>Delete</button></td>";
      echo "<td><button type='submit' name='update' value='update'>Update</button></td>";
      echo "</form>";
      echo "</tr>";
  }
  
  
  
  
               ?>
               </table>
               
               

               </div>
            </div>
         </div>
      </div>
      <!-- contact -->
      <!--  footer -->
      <footer>
         <div class="footer">
            <div class="container">
               <div class="row">
                  <div class="col-lg-3 col-md-6 col-sm-6">
                     <div class="infoma text_align_left">
                        <!-- <h3>Choose.</h3>
                        <ul class="commodo">
                           <li>Commodo</li>
                           <li>consequat. Duis a</li>
                           <li>ute irure dolor</li>
                           <li>in reprehenderit </li>
                           <li>in voluptate </li>
                        </ul> -->
                     </div>
                  </div>
                  <div class="col-lg-4 col-md-6 col-sm-6">
                     <div class="infoma">
                        <!-- <h3>Get Support.</h3> -->
                        <ul class="conta">
                           <li><i class="fa fa-map-marker" aria-hidden="true"></i>Address : No.44, Pagoda Road, Nugegoda
                           </li>
                           <li><i class="fa fa-phone" aria-hidden="true"></i>Call : +94 70 100 1315</li>
                           <li> <i class="fa fa-envelope" aria-hidden="true"></i><a href="Javascript:void(0)"> Email : mtfesrilanka@gmail.com</a></li>
                        </ul>
                     </div>
                  </div>
                  <div class="col-lg-3 col-md-6 col-sm-6">
                     <div class="infoma">
                        <h3>MTFE</h3>
                        <ul class="menu_footer">
                           <li><a href="index.html">Dashboard</a></li>
                           <li><a href="search_by_city.html">Search by City </a></li>
                           <li><a href="leader_list.html">Leader List</a></li>
                           <li><a href="add_users.html">Add User</a></li>
                           <li><a href="update_delete.html">Update/Delete</a></li>
                        </ul>
                     </div>
                  </div>
                  <div class="col-lg-2 col-md-6 col-sm-6">
                     <div class="infoma text_align_left">
                        <!-- <h3>Services.</h3>
                        <ul class="commodo">
                           <li>Commodo</li>
                           <li>consequat. Duis a</li>
                           <li>ute irure dolor</li>
                           <li>in reprehenderit </li>
                           <li>in voluptate </li>
                        </ul> -->
                     </div>
                  </div>
               </div>
            </div>
            <div class="copyright">
               <div class="container">
                  <div class="row">
                     <div class="col-md-12">
                        <p>© <script>document.write(/\d{4}/.exec(Date())[0])</script> All Rights Reserved. <a href="https://html.design/"> MTFEUSERDATABASE</a></p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </footer>
      <!-- end footer -->
      <!-- Javascript files-->
      <script src="js/jquery.min.js"></script>
      <script src="js/bootstrap.bundle.min.js"></script>
      <!-- sidebar -->
      <script src="js/custom.js"></script>
   </body>
</html>