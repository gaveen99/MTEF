<?php
// Connect to the SQL database

// Connection variables
$host = "localhost:8889";
$user = "root";
$password = "root";
$database = "MTFE";

// Connect to the database
$conn = mysqli_connect($host, $user, $password, $database);

// Retrieve the data for the selected city from the database
$city = $_POST['city'];
$result = mysqli_query($conn, "SELECT * FROM USERS WHERE city = '$city'");

// Build the table of data
$table = "<br><br><br><br><br><br><br><table><tr><th>ID</th><th>NAME</th><th>Phone Number</th><th>Email</th><th>City</th><th>Whatsapp Number</th><th>Telegram Number</th><th>Leader Name</th><th>Trading Status</th><th>Number of members</th></tr> ";
while ($row = mysqli_fetch_assoc($result)) {
    $table .= "<tr><td>" . $row['id'] . "</td><td>" . $row['name'] . "</td><td>" . $row['p_number'] . "</td><td>" . $row['email'] . "</td><td>" . $row['city'] . "</td><td>" . $row['whatsapp'] . "</td><td>" . $row['telegram'] . "</td><td>" . $row['leader'] . "</td><td>" . $row['trader_stat'] . "</td><td>" . $row['num_mem'] . "</td></tr> ";
     
}
$table .= "</table>";

// Return the table of data
echo $table;

?>
 <!-- `id`, `name`, `p_number`, `email`, `city`, `whatsapp`, `telegram`, `leader`, `trader_stat`, `num_mem` -->