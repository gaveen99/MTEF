<?php
// Connection variables
$servername = "localhost:3306";
$dbusername = "naletans_MTFE__DB__1531";
$dbpassword = "Mtfe__1515";
$dbname = "naletans_MTFE";

// Connect to the database
$conn = mysqli_connect($host, $user, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: ");
}



if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $p_number = $_POST['p_number'];
    $email = $_POST['email'];
    $city = $_POST['city'];
    $whatsapp = $_POST['whatsapp'];
    $telegram = $_POST['telegram'];
    $leader = $_POST['leader'];
    $trader_stat = $_POST['trader_stat'];
    $num_mem = $_POST['num_mem'];

    

    if ($_POST['action'] == 'delete') {
        $sql = "DELETE FROM `USERS` WHERE `id` = '$id'";
        if (mysqli_query($conn, $sql)) {
            header("Location: front.php?message=Record deleted successfully");
        } else {
            header("Location: front.php?message=Error deleting record: " . mysqli_error($conn));
        }
    } elseif ($_POST['update'] == 'update') {
        $sql = "UPDATE `USERS` SET `name` = '$name', `p_number` = '$p_number', `email` = '$email', `city` = '$city', `whatsapp` = '$whatsapp', `telegram` = '$telegram', `leader` = '$leader', `trader_stat` = '$trader_stat', `num_mem` = '$num_mem' WHERE `id` = '$id'";
        if (mysqli_query($conn, $sql)) {
            header("Location: front.php");
        } else {
            header("Location: front.php?" . mysqli_error($conn));
        }
    }
}

// Close the connection
mysqli_close($conn);
