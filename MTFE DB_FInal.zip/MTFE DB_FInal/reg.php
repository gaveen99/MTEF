
	<?php
		// Check if the form has been submitted
		if ($_SERVER["REQUEST_METHOD"] == "POST") {
			
			// Collect form data
			$user = $_POST['username'];
			$role = $_POST['role'];
			$pass = $_POST['password'];
			$confirm_password = $_POST['confirm_password'];

			// Check if the passwords match
			if ($pass == $confirm_password) {
				
				// Hash the password using bcrypt
				// $hashed_password = password_hash($pass, PASSWORD_BCRYPT);
                $hashed_password=hash('sha256', $pass);

				// Connect to the SQL server
				$servername = "localhost:3306";
				$dbusername = "naletans_MTFE__DB__1531";
				$dbpassword = "Mtfe__1515";
				$dbname = "naletans_MTFE";

				

				$conn = mysqli_connect($servername, $username, $password, $dbname);

				// Check connection
				if (!$conn) {
				  die("Connection failed: " . mysqli_connect_error());
				}

				// Insert the user's information into the database
				$sql = "INSERT INTO accounts (`username`, `role`, `password`) VALUES ('$user', '$role', '$hashed_password')";

				if (mysqli_query($conn, $sql)) {
				  echo "<p>Registration successful!</p>";
				} else {
				  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
				}

				mysqli_close($conn);

			} else {
				echo "<p>Passwords do not match. Please try again.</p>";
			}

		}
	?>


<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Login Page in HTML with CSS Code Example</title>
  <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">


<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous"><link rel="stylesheet" href="./reg_style.css">

</head>
<body>
<!-- partial:index.partial.html -->
<div class="box-form">
	<div class="left">
		<div class="overlay">
		<h1>WELCOME ! &nbsp;&nbsp;&nbsp;&nbsp;</h1>
		<!-- <p>MTFESL GROUP</p> -->
		<!-- <span>
			<p>login with social media</p>
			<a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
			<a href="#"><i class="fa fa-twitter" aria-hidden="true"></i> Login with Twitter</a>
		</span> -->
		</div>
	</div>
	
	
		<div class="right">
		<h1>Registration</h1>
		<p>Have an account? <a href="login.php">Login from here</a> &nbsp;</p>
		<div class="inputs">
		<form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
		
		<input type="text" id="username" name="username" placeholder="Username"><br><br>
		<!-- <label for="role">Role:</label>
		<input type="text" id="role" name="role"><br><br> -->
        

                        <select class="contactus" name="role" id="role">
                       <option value="CEO">CEO</option>
                        <option value="ADMIN">ADMIN</option>
                        </select>


		
		<input type="password" id="password"  placeholder="Password" name="password"><br><br>
	
		<input type="password" id="confirm_password" name="confirm_password" placeholder="Confirm Password"><br><br>
		<input type="submit" value="Register" class="btl">
	</form>
		</div>
			
			<br><br>
			

	
</div>
<!-- partial -->
  
</body>
</html>


