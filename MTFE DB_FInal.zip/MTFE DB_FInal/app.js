const root = document.getElementById("root");

const fetchData = () => {
  // Here you would fetch data from your database system using an API
  // For this example, let's assume you've fetched the following data
  const data = [
    { id: 1, name: "John Doe", age: 30 },
    { id: 2, name: "Jane Doe", age: 25 },
    { id: 3, name: "Jim Smith", age: 40 }
  ];

  return data;
};

const renderData = data => {
  const table = document.createElement("table");

  const headerRow = document.createElement("tr");
  const headerId = document.createElement("th");
  headerId.innerText = "ID";
  headerRow.appendChild(headerId);
  const headerName = document.createElement("th");
  headerName.innerText = "Name";
  headerRow.appendChild(headerName);
  const headerAge = document.createElement("th");
  headerAge.innerText = "Age";
  headerRow.appendChild(headerAge);
  table.appendChild(headerRow);

  data.forEach(item => {
    const row = document.createElement("tr");
    const id = document.createElement("td");
    id.innerText = item.id;
    row.appendChild(id);
    const name = document.createElement("td");
    name.innerText = item.name;
    row.appendChild(name);
    const age = document.createElement("td");
    age.innerText = item.age;
    row.appendChild(age);
    table.appendChild(row);
  });

  root.appendChild(table);
};

const data = fetchData();
renderData(data);
