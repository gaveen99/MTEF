

<?php
if (isset($_POST['delete'])) {
  $id = $_POST['id'];

  $sql = "DELETE FROM `accounts` WHERE `id` = '$id'";
  if (mysqli_query($conn, $sql)) {
    header("Location: front.php");
  } else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
  }
}
?>